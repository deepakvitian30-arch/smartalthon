from flask import Flask, request, jsonify
from book_finder_app import BookFinder  # Your existing class

app = Flask(__name__)
finder = BookFinder()

@app.route('/search', methods=['POST'])
def search():
    query = request.json.get('query')
    results = finder.search_book(query)  # Your existing search method
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)