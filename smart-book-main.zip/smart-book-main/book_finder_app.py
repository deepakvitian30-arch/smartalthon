import json
import requests
from difflib import get_close_matches
from urllib.parse import quote

# API Configuration
GOOGLE_BOOKS_API = "https://www.googleapis.com/books/v1/volumes?q="
OPEN_LIBRARY_API = "https://openlibrary.org/search.json?subject="

class ProfessionalBookFinder:
    def __init__(self):
        self.local_books = self.load_local_books()
        self.cache = {}  # Cache for API responses
    
    def load_local_books(self):
        """Load enhanced local book database"""
        books = {
            "harrypotter": {
                "title": "Harry Potter and the Philosopher's Stone",
                "author": "J.K. Rowling",
                "genre": "fantasy",
                "price": "$12.99",
                "pages": 223,
                "summary": "A young boy discovers he's a wizard and attends Hogwarts."
            },
            "thehobbit": {
                "title": "The Hobbit",
                "author": "J.R.R. Tolkien",
                "genre": "fantasy",
                "price": "$14.95",
                "pages": 310,
                "summary": "Bilbo Baggins goes on an adventure to reclaim treasure."
            },
            "atomichabits": {
                "title": "Atomic Habits",
                "author": "James Clear",
                "genre": "self-help",
                "price": "$11.49",
                "pages": 319,
                "summary": "A guide to building good habits and breaking bad ones."
            }
        }
        return books

    def smart_search(self, user_input):
        """Find closest matching book title with spelling correction"""
        user_input = user_input.lower().strip().replace(" ", "")
        book_titles = list(self.local_books.keys())
        matches = get_close_matches(user_input, book_titles, n=1, cutoff=0.6)
        return matches[0] if matches else None

    def fetch_from_api(self, url):
        """Get data from API with caching"""
        if url in self.cache:
            return self.cache[url]
        try:
            response = requests.get(url)
            data = response.json()
            self.cache[url] = data
            return data
        except:
            return None

    def get_recommendations(self, genre, exclude_title):
        """Get recommendations from same genre"""
        # First try local books
        local_recs = [
            book for title, book in self.local_books.items()
            if book['genre'] == genre and title != exclude_title
        ][:2]  
        
        # Then try API for more recommendations
        api_recs = []
        api_data = self.fetch_from_api(f"{OPEN_LIBRARY_API}{quote(genre)}")
        if api_data and 'docs' in api_data:
            for doc in api_data['docs'][:3]:  # Get max 3 API recommendations
                if 'title' in doc and 'author_name' in doc:
                    api_recs.append({
                        'title': doc['title'],
                        'author': doc['author_name'][0],
                        'source': 'Open Library'
                    })
        
        return local_recs + api_recs  # Combine all

    def display_book(self, book_info, corrected_query=None):
        """Display rich book information with recommendations"""
        print("\n" + "="*60)
        if corrected_query:
            print(f"🔍 Did you mean: {book_info['title']}?")

        print(f"\n📖 Title: {book_info['title']}")
        print(f"✍️ Author: {book_info['author']}")
        print(f"💰 Price: {book_info.get('price', 'Not available')}")
        print(f"⭐ Genre: {book_info.get('genre', 'Unknown').title()}")
        print(f"📏 Pages: {book_info.get('pages', 'N/A')}")

        print("\n📝 Summary:")
        print(book_info.get('summary', 'No summary available'))

        # Get and display recommendations
        if 'genre' in book_info:
            recommendations = self.get_recommendations(
                book_info['genre'],
                book_info['title'].lower().replace(' ', '')
            )
            if recommendations:
                print("\n🌟 Recommended Similar Books:")
                for i, book in enumerate(recommendations, 1):
                    source = book.get('source', 'Our Collection')
                    print(f"{i}. {book['title']} by {book['author']} ({source})")

        print("="*60)

    def search_book(self, query):
        """Main search function"""
        # Try local books first
        corrected_title = self.smart_search(query)
        if corrected_title:
            book_info = self.local_books[corrected_title]
            self.display_book(book_info, corrected_query=query)
            return

        # Fallback to Google Books API
        api_data = self.fetch_from_api(f"{GOOGLE_BOOKS_API}{quote(query)}")
        if api_data and 'items' in api_data:
            item = api_data['items'][0]
            volume_info = item.get('volumeInfo', {})
            sale_info = item.get('saleInfo', {})
            retail_price = sale_info.get('retailPrice', {}).get('amount', 'N/A')
            book_info = {
                'title': volume_info.get('title', query),
                'author': ', '.join(volume_info.get('authors', ['Unknown'])),
                'summary': volume_info.get('description', 'No summary available'),
                'price': f"${retail_price}" if isinstance(retail_price, (int, float)) else "Not available",
                'pages': volume_info.get('pageCount', 'N/A'),
                'genre': ', '.join(volume_info.get('categories', ['Unknown'])[:1])
            }
            self.display_book(book_info)
        else:
            print("\n Book not found. Try these available books:")
            print(", ".join([book['title'] for book in self.local_books.values()][:3]))

def main():
    print("\n Professional Book Finder with Smart Recommendations")
    print("(Type 'exit' to quit)\n")
    finder = ProfessionalBookFinder()

    while True:
        try:
            query = input("\nEnter book name: ").strip()
            if query.lower() == 'exit':
                print("\nThank you for using our service!")
                break
            if not query:
                print(" Please enter a book name")
                continue
            finder.search_book(query)
        except KeyboardInterrupt:
            print("\nOperation cancelled")
            break
        except Exception as e:
            print(f"\n Error: {str(e)}")

if __name__ == "__main__":
    main()
