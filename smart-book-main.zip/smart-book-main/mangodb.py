from pymongo import MongoClient

# Step 1: Replace with your MongoDB URI
client = MongoClient("mongodb+srv://<username>:<password>@cluster0.mongodb.net/?retryWrites=true&w=majority")

# Step 2: Choose your database and collection
db = client["book_database"]           # Create/use database
collection = db["books_collection"]    # Create/use collection

# Step 3: Sample book data (can be loaded from JSON too)
book_data = {
    "title": "Harry Potter and the Philosopher's Stone",
    "author": "J.K. Rowling",
    "year": 1997,
    "genre": "Fantasy",
    "summary": "Harry discovers he is a wizard and attends Hogwarts."
}

# Step 4: Insert the book data
result = collection.insert_one(book_data)

# Optional: Print inserted ID
print("Inserted document ID:", result.inserted_id)
