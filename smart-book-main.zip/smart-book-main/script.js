// Add event listener for Enter key
const searchInput = document.getElementById('searchInput');
searchInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        searchBook();
    }
});

function searchBook() {
    const query = searchInput.value.trim();
    if (!query) {
        showError('Please enter a book name or author');
        return;
    }

    const resultsContainer = document.getElementById('results');
    resultsContainer.innerHTML = '<div class="loading-spinner"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';

    fetch(`/api/search?query=${encodeURIComponent(query)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                showError(data.error);
                return;
            }

            const bookCard = document.createElement('div');
            bookCard.className = 'book-card';

            // Book Info
            const bookInfo = document.createElement('div');
            bookInfo.className = 'book-info';
            
            if (data.title) {
                const title = document.createElement('h2');
                title.textContent = data.title;
                bookInfo.appendChild(title);
            }

            if (data.author) {
                const author = document.createElement('p');
                author.textContent = `Author: ${data.author}`;
                bookInfo.appendChild(author);
            }

            if (data.price) {
                const price = document.createElement('p');
                price.className = 'price';
                price.textContent = `Price: ${data.price}`;
                bookInfo.appendChild(price);
            }

            if (data.genre) {
                const genre = document.createElement('p');
                genre.className = 'genre';
                genre.textContent = data.genre;
                bookInfo.appendChild(genre);
            }

            if (data.summary) {
                const summary = document.createElement('div');
                summary.className = 'summary';
                summary.innerHTML = `<p><strong>Summary:</strong></p><p>${data.summary}</p>`;
                bookInfo.appendChild(summary);
            }

            bookCard.appendChild(bookInfo);

            // Recommendations
            if (data.recommendations && data.recommendations.length > 0) {
                const recommendations = document.createElement('div');
                recommendations.className = 'recommendations';
                recommendations.innerHTML = '<h3>Recommended Books:</h3>';

                const recommendationsList = document.createElement('div');
                recommendationsList.className = 'recommendations-list';

                data.recommendations.forEach((book, index) => {
                    const recommendationItem = document.createElement('div');
                    recommendationItem.className = 'recommendation-item';
                    recommendationItem.innerHTML = `
                        <div class="recommendation-number">${index + 1}.</div>
                        <div class="recommendation-details">
                            <h4>${book.title}</h4>
                            <p class="author">${book.author}</p>
                        </div>
                    `;
                    recommendationsList.appendChild(recommendationItem);
                });

                recommendations.appendChild(recommendationsList);
                bookCard.appendChild(recommendations);
            }

            resultsContainer.innerHTML = '';
            resultsContainer.appendChild(bookCard);
        })
        .catch(error => {
            console.error('Error:', error);
            showError(`An error occurred: ${error.message}`);
        });
}

function showError(message) {
    const resultsContainer = document.getElementById('results');
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    resultsContainer.innerHTML = '';
    resultsContainer.appendChild(errorDiv);
}

